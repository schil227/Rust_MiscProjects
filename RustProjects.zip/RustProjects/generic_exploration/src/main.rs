struct Point<'a, T>{
    x: T,
    y: T,
    z: &'a T
}

impl<'a, T> Point<'a, T>{
    pub fn x(&self)-> &T{
        &self.x
    }

    pub fn new(x: T, y: T, z: &'a T)-> Point<'a, T>{
        Point{
            x: x,
            y: y,
            z: z
        }
    }

    pub fn zed(&self) -> &'a T{
        self.z
    }
}

impl<'a, T: PartialOrd > Point<'a, T>{
    pub fn cmp_point(&self) -> &T{
        if(self.x > self.y){
            &self.x
        }
        else{
            &self.y
        }
    }
}

impl<'a> Point<'a, f32>{
    pub fn f32_x(&self)-> f32{
        self.x + self.x
    }
}

fn main() {
    let nums: &Vec<i32> = &vec![5,20,9,3,2,11,333,1024];

    let largest_num = largest(nums);

    println!("The largest i32 is: {}", largest_num);

    let letters: &Vec<char> = &vec!['y', 'm', 'a', 'q'];

    let largest_char = largest(letters);

    println!("The largest char is: {}", largest_char);

    let foo = Point{x: 1, y: 2, z: &3};
    let bar = Point{x: 2.4, y: 30.2, z: &33.3};

    println!("Points: {:?}, {:?}", foo.x(), bar.f32_x());
    println!("The bigger part of point: {}", foo.cmp_point());
    println!("The bigger part of point: {}", bar.cmp_point());

    // this will work, since longest_string is in the same scope as str2, the smaller one
    let str1 = String::from("abcd");
    {
        let str2 = "xyz";

        let longest_string = longest(str1.as_str(), str2);
        println!("The longer string: {}", longest_string);
    }

    // this wont work, since longest_string's scope is limited to str2's above
    // println!("The longer string: {}", longest_string);

    let bang = Point{
        x: "Foo",
        y: "Bar",
        z: &"Bang!"
    };

    println!("The bigger part of point: {}", bang.cmp_point());

    let zed = bang.zed();

    println!("The Zed Value: {}", zed);
}

fn largest_i32(nums: Vec<i32>) -> i32{
    let mut largest = nums[0];

    for num in nums{
        if num > largest{
            largest = num;
        }
    }

    return largest;
}

fn largest_char(chars: Vec<char>) -> char{
    let mut largest = chars[0];

    for c in chars{
        if c > largest{
            largest = c;
        }
    }

    return largest;
}

fn largest<T: PartialOrd>(list: &Vec<T> ) -> &T{
    let mut largest: &T = &list[0];

    for item in list{
        if item > largest{
            largest = item;
        }
    }

    return largest;
}

// we're taking string slices (references) here because we dont want longest() to take 
// ownership of its parameters.
fn longest<'a>(x: &'a str, y: &'a str) -> &'a str{
    if(x.len() > y.len()){
        x
    }
    else{
        y
    }
}