fn main() {
    let mut num = 5;

    let r1 = &num as *const i32;
    let r2 = &mut num as *mut i32;

    unsafe{
        println!("ref1: {}", *r1);
        println!("ref2: {}", *r2);

        *r2 = 10;

        println!("ref1: {}", *r1);
        println!("ref2: {}", *r2);
    }
}
