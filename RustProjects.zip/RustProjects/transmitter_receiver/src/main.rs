use std::sync::mpsc;
use std::thread;
use std::time::Duration;

fn main() {
    // mpsc: Multiple Producer Single Consumer
    let (tx, rx) = mpsc::channel();
    let mut count = 0;

    let tx_handler = thread::spawn(move || {
        loop{
            if count == 100 {
                tx.send("And I'm done!".to_string()).unwrap();
                break;
            }
            let val = format!("Hi! {}", count);

            count += 1;
    
            tx.send(val).unwrap();

            thread::sleep(Duration::from_millis(10));
        }
    });

    // runs until the channel is closed by either tx or rx
    for received in rx{
        println!("Msg: {}", received);
    }

    println!("Waiting for tx to finish.");

    tx_handler.join().unwrap();

    println!("Done sending!");
    thread::sleep(Duration::from_secs(4));
}
