fn main() {
    // assert_eq!(patterns_are_wild(Some("Black"), false, Err("No age")), "Using your favorite color, Black, as the background");
    // assert_eq!(patterns_are_wild(None, true, Err("No age")), "Tuseday is green day buddy");
    // assert_eq!(patterns_are_wild(None, false, Err("No age")), "We're gonna default to blue on that one.");
    // assert_eq!(patterns_are_wild(None, false, Ok(31)), "you're older than 30, your color is purple");
    // assert_eq!(patterns_are_wild(None, false, Ok(29)), "using orange.");

    // while_let_example();

    // pattern_scope_variable();

    // underscore_guard_example();

    // match_guards(10);
    // match_guards(4);
    // match_guards(0);

    bindings();
}

fn patterns_are_wild(favorite_color: Option<&str>, is_tuesday: bool, age: Result<u8, &str>) -> String{
    if let Some(color) = favorite_color{
        format!("Using your favorite color, {}, as the background", color)
    } else if is_tuesday {
        format!("Tuseday is green day buddy")
    } else if let Ok(age) = age{
        if age > 30{
            format!("you're older than 30, your color is purple")
        }else{
            format!("using orange.")
        }
    } else {
        format!("We're gonna default to blue on that one.")
    }
}

fn while_let_example(){
    let mut nums = Vec::new();
    nums.push(1);
    nums.push(2);
    nums.push(3);
    nums.push(4);
    nums.push(5);

    while let Some(top) = nums.pop(){
        println!("Top of the stack: {}", top);
    }
}

fn pattern_scope_variable(){
    let x = Some(5);
    let y = 10;

    match x {
        Some(50) => println!("Got 50."),
        Some(y) => println!("got y: {}", y),
        _ => println!("Got effectively nothin.")
    }

    println!("x: {:?}, y: {:?}", x, y)
}

fn underscore_guard_example(){
    let mut value = Some(10);
    let new_value = Some(5);
    let mut none: Option<i32> = None;

    update_if_none(&mut value, &new_value);

    println!("Value: {}", value.unwrap());

    update_if_none(&mut none, &new_value);

    println!("none?: {}", none.unwrap());
}

fn update_if_none(value: &mut Option<i32>,new_value: &Option<i32>){
    match (&value, new_value){
        (&Some(_), Some(_)) =>{println!("value cannot be overwritten.")}
        _ => { *value = *new_value }
    }
}

fn match_guards(score: i32){
    let mut num = Some(score);

    if score == 0{
        num = None;
    }

    match num{
        Some(x) if x > 7 => {println!("score: {} - nice job!", x)}
        Some(x) => {println!("score: {} - try again!", x)}
        None => {println!("Failed! better luck next time!")}
    }
}

fn bindings(){
    enum Message{
        Hello {id:i32},
    }
    
    let msg = Message::Hello{id:1};

    match msg{
        Message::Hello{
            id: id_variable @ 3..=7,
        } => println!("Found an id within range: {}", id_variable),
        Message::Hello{
            id: 8..=12,
        } => println!("Message over!"),
        Message::Hello{id} => println!("no message. {}", id)
    }

}

