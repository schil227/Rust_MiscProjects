use std::thread;
use std::time::Duration;

struct Cacher<T> where T: Fn(u32) -> u32
{
    calculation: T, // calculation is a closure that takes a u32, returns u32; thus creating a contract
    value: Option<u32> // this will be None before we execute.
}

impl<T> Cacher<T> where T: Fn(u32) -> u32{
    fn new(calcuation: T) -> Cacher<T>{
        Cacher{
            calculation: calcuation,
            value: None
        }
    }

    //note, the value property is private, must go through this getter
    fn value(&mut self, arg: u32) -> u32{
        match self.value{
            Some(val) => val,
            None =>{
                let value = (self.calculation)(arg);
                self.value = Some(value);
                value
            } 
        }
    }
} 

fn main() {
    let simulated_user_specified_value = 100;
    let simulated_random_number = 3;

    generate_workout(simulated_user_specified_value, simulated_random_number);

    closure_in_scope_example();
}

fn generate_workout(intensity: u32, random_number: u32){
    // The closure
    let mut expensive_result = Cacher::new( |intensity|{
        println!("Calculating slowly...");
        thread::sleep(Duration::from_secs(2));
        intensity
    });

    if intensity < 25{
        println!("Today, do {} pushups!", expensive_result.value(intensity));
        println!("Then, do {} situps!", expensive_result.value(intensity));
    } else {
        if random_number == 3 {
            println!("Take the day off, champ! Stay hydrated!");
        } else{
            println!("Today, Jog for {} minutes", expensive_result.value(intensity));
        }
    }
}

fn closure_in_scope_example(){
    let x = 4;

    let is_equal = |z| z == x;

    let y = 5;

    assert!(is_equal(y));
}

fn cant_ref_envionment_with_fn(){
    let x = 4;

    fn is_equal(z: i32)->bool{
        // z == x
        // Doesnt compile, because x is in different scope.
        true
    }

    let y = 5;

    assert!(is_equal(y))
}