mod model;
mod service;

use model::employee::Employee;
use model::department::Department;
use model::company::Company;
use service::department_service;
use service::company_service;

fn main() {
    let foo = Employee{
        first_name: "foo".to_string(),
        last_name: "bar".to_string()
    };

    // let mut dep = Department::create_department("Engineering".to_string());

    // &dep.add_employee(foo);
    // dep.add_employee()

    let dep_name = String::from("Engineering");

    let dep = vec![dep_name.clone(), String::from("Sales"), String::from("Accounting")];

    let mut company = Company::create_company("Foo Inc.".to_string(), dep);

    // Why this took so long to do:
    // the &mut company was necessiray, because company's department was going to be changed in this scope. if the department changes,
    // then the company changes.
    match &mut company.get_department(dep_name.clone()){
        Some(department) => {
            &mut department.add_employee(foo);
        },
        None => println!("Department '{}' not found.", dep_name.clone())
    };

    company.print();
}
