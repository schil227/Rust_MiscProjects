use super::department::Department;

pub struct Company{
    pub name: String,
    pub departments: Vec<Department>
}