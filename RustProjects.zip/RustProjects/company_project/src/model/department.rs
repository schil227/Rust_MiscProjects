use super::employee::Employee;

pub struct Department{
    pub name: String,
    pub employees: Vec<Employee>
}