pub enum Action{
    AddDepartment(String),
    RemoveDepartment(String),
    AddEmployee(String, String, String),
    RemoveEmployee(String, String, String),
    PrintCompany
}