use crate::model::employee::Employee;

impl Employee{
    pub fn print_employee(&self){
        println!("Employee: {}, {}", self.first_name, self.last_name);
    }
}