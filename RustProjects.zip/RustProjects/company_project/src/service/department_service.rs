use crate::model::department::Department;
use crate::model::employee::Employee;

pub fn asdf_create_departmentx(department_name: String) -> Department{
    Department::create_department(department_name)
}

impl Department{
    pub fn create_department(department_name: String) -> Department{
        Department{
            name: department_name,
            employees: Vec::new()
        }
    }

    pub fn add_employee(&mut self, new_employee: Employee){
        self.employees.push(new_employee);
    }

    pub fn print(&self){
        println!("== {} ==", self.name);

        for emp in self.employees.iter(){
            emp.print_employee();
        }
    }
}