use crate::model::company::Company;
use crate::model::department::Department;

impl Company{
    pub fn create_company(comapny_name: String, department_names: Vec<String>) -> Company{
        let mut departments = Vec::new();

        for department_name in department_names.iter(){
            departments.push(Department::create_department(department_name.to_string()));
        }
        
        Company{
            name: comapny_name,
            departments: departments
        }
    }

    pub fn print(&self){
        println!("=== {} ===", self.name.to_uppercase());

        for dep in self.departments.iter(){
            dep.print();
        }
    }

    pub fn get_department(&mut self, department_name: String) -> Option<&mut Department>{
        for dep in self.departments.iter_mut(){
            if dep.name == department_name {
                return Some(dep);
            }
        }

        None
    }
}