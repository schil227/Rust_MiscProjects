use std::thread;
use std::time::Duration;

fn main() {
    another_example();

    let join_handle = thread::spawn(|| {
        for i in 1..10{
            println!("Hi number {} from spawned thread!", i);
            thread::sleep(Duration::from_millis(1));
        }
    });

    for i in 1..5{
        println!("Hi number {} from main thread!", i);
        thread::sleep(Duration::from_millis(1));
    }

    // await here
    join_handle.join().unwrap();
}


pub fn another_example(){
    let v = vec![1,2,3];

    let handle = thread::spawn(move || {
        println!("Here's what's in v: {:?}", v);
    });


    handle.join().unwrap();
}
