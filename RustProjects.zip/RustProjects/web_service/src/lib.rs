use std::thread::JoinHandle;
use std::sync::{Arc, Mutex,mpsc};

type Job = Box<dyn FnOnce() + Send + 'static>;

enum Message{
    Job(Job),
    Terminate
}

struct Worker{
    id:usize,
    thread_handler: Option<JoinHandle<()>>
}

pub struct ThreadPool{
    workers:Vec<Worker>,
    sender:mpsc::Sender<Message>
}

impl Worker{
    pub fn new(id:usize, reciever: Arc<Mutex<mpsc::Receiver<Message>>>) -> Worker{
        Worker{
            id,
            thread_handler: Some(std::thread::spawn(move || loop {
                    let message = reciever.lock().unwrap().recv().unwrap();

                    match message {
                        Message::Terminate =>{
                            println!("Terminating thread! Worker: {}", id);
                            break;
                        },
                        Message::Job(job) =>{ 
                            println!("Worker {} processing.", id);

                            job();
        
                            println!("Worker {} finished.", id);
                        }
                    }
            }))
        }
    }
}

impl ThreadPool{
    pub fn new(max_threads: usize) -> ThreadPool{
        assert!(max_threads > 0);

        let (sender, receiver) = mpsc::channel();

        let shared_receiver = Arc::new(Mutex::new(receiver));

        let mut workers = Vec::with_capacity(max_threads);

        for i in 0..max_threads{
            workers.push(Worker::new(i, Arc::clone(&shared_receiver)));
        }

        ThreadPool{
            workers,
            sender
        }
    }

    pub fn execute<F>(&self, f: F)
        where
        F: FnOnce() + Send + 'static,
    {
        self.sender.send(
            Message::Job(Box::new(f))).unwrap();
    }
}

impl Drop for ThreadPool{
    
    fn drop(&mut self) { 
        for _ in self.workers.iter() {
            self.sender.send(Message::Terminate).unwrap();
        } 

        println!("Shutdown messages sent.");

        for worker in &mut self.workers {
            println!("Shutting down worker {}", worker.id); 

            if let Some(thread) = worker.thread_handler.take(){
                thread.join().unwrap();
            }
        } 
    }
}