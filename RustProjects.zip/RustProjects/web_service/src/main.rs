use web_service::ThreadPool;

use std::io::prelude::*;
use std::net::{TcpListener, TcpStream};
use std::fs;
use std::thread;
use std::time::Duration;

fn main() {
    // we are listening to localhost port 7878
    // fun fact: 7878 ususally accepts Http, and it's RUST typed on a telephone!
    let listener = TcpListener::bind("127.0.0.1:7878").unwrap();
    let pool: ThreadPool = ThreadPool::new(2);

    // listener.incoming is like calling accept over and over again. once it works, it will give us the stream
    for stream in listener.incoming().take(20){
        let stream = stream.unwrap();

        pool.execute(|| {
            println!("Connection established.");
            handle_connection(stream);
        });
    }

    println!("Shutting down server.");
}

fn handle_connection(mut stream: TcpStream){
    let mut buffer = [0; 1024];

    stream.read_exact(&mut buffer).unwrap();

    // println!("Request: {}", String::from_utf8_lossy(&buffer[..]));

    // Note: b".." means as byte array. Neato!
    let get = b"GET / HTTP/1.1";
    let sleep = b"GET /sleep HTTP/1.1";

    let response_content = if buffer.starts_with(get){
        ("HTTP/1.1 200 OK\r\n", "hello.html")
    } else if buffer.starts_with(sleep){
        thread::sleep(Duration::from_secs(5));
        ("HTTP/1.1 200 OK\r\n", "hello.html")
    }
    else {
        ("HTTP/1.1 404 NOT_FOUND\r\n", "not_found.html")
    };

    let content = fs::read_to_string(response_content.1).unwrap();

    let response = format!("{}{}{}", response_content.0, "Content-Length={}\r\n\r\n", content);

    stream.write_all(response.as_bytes()).unwrap();
    // FLUSH: prevents the program from continuing until all bytes are written to the connection (stream)
    // This is necessairy, since a buffer is used to prevent sending streaming data immediately to mimimize
    // calls to the underlying OS.
    // stream.flush().unwrap();
}
