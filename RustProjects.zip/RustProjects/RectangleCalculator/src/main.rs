#[derive(Debug)]
struct Rectangle {
    width: u32,
    height: u32
}

impl Rectangle {
    fn area(&self) -> u32{
        self.width * self.height
    }

    fn set_width(&mut self, width: u32){
        self.width = width;
    }

    fn set_height(&mut self, height: u32){
        self.height = height;
    }

    fn can_hold(&self, rect: &Rectangle) -> bool{
        self.height >= rect.height && self.width >= rect.width
    }

    fn create_rect(width: u32, height: u32) -> Rectangle {
        Rectangle{
            width: width,
            height: height
        }
    }
}

fn main() {
    let mut rect1 = Rectangle::create_rect(31, 24);

    let rect2 = Rectangle::create_rect(5, 10);

    println!("{:?} hold {:?}? :{}", rect1, rect2, rect1.can_hold(&rect2));

    rect1.set_height(4);
    rect1.set_width(3);

    println!("{:?} hold {:?}? :{}", rect1, rect2, rect1.can_hold(&rect2));
}