use std::fs::File;
use std::io::prelude::*;
use std::io::BufReader;
use std::fs::OpenOptions;
use std::collections::HashMap;
use std::fmt;

fn main() {
    let lines = read_input_file();

    let mapped_count = map_unique_line_count(lines);

    write_data_to_file(mapped_count);
}

fn read_input_file() -> Vec<String>{
    let input_file = open_file(".\\input.txt", false);

    let reader = BufReader::new(input_file);

    reader.lines()
        .map(|l| l.expect("Failed reading the line!"))
        .collect()
}

fn open_file(file_name: &str, write: bool) -> File{
    match OpenOptions::new().read(true).write(write).open(file_name, ){
        Ok(file) => file,
        Err(error) => {
            match File::create(file_name){
                Ok(file) => file,
                Err(error) => panic!("Something bad happend: {:?}", error)
            }
        }
    }
}

fn map_unique_line_count(lines: Vec<String>) -> HashMap<String, u32>{
    let mut map: HashMap<String, u32> = HashMap::new();
   
    for line in lines{
        let count = map.entry(line).or_insert(0);
        *count += 1;
    }

    return map;
}

fn get_ordered_list(map: HashMap<String, u32>) -> Vec<(String, u32)>{
    let mut list = Vec::new();
    
    for (k,v) in map{
        list.push((k,v));
    }

    list.sort_by(|a,b| a.0.cmp(&b.0));

    list
}

fn write_data_to_file(map: HashMap<String, u32>){
    let mut out_file = open_file(".\\output.txt", true);

    let sorted_list = get_ordered_list(map);

    for (k,v) in sorted_list{
        let out_str = format!("{},{}\r\n",k,v);
        out_file.write_all(out_str.as_bytes()).expect("Failed to write to file!");
    }
}