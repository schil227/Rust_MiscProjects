use std::fs::File;
use std::io::ErrorKind;
use std::io::Error;
use std::io::Read;

fn main() {
    let mut file = open_file(String::from("hello.txt"));

    // let mut file_content = &mut String::new();

    // let outstr = file.read_to_string(file_content);

    let mut s = String::new();

    let data = match file.read_to_string(&mut s){
        Ok(data) => s,
        Err(error) => panic!("Uh oh! {:?}", error)
    };

    println!("Read the data! Data: {}", data);

    let data = conscice_read_from_file().unwrap();

    println!("Also read data from the file this way: {}", data);

    let fail = match fail_opening_file(){
        Ok(file) => file,
        Err(error) => {println!("Failed opening foo_file.txt: {:?}", error);
            open_file("foo.txt".to_string())}
    };

    println!("Didn't crash! =D");
}

fn conscice_read_from_file() -> Result<String, Error>{
    let mut s = String::new();

    let mut f = File::open("hello.txt")?.read_to_string(&mut s)?;

    Ok(s)
}

fn fail_opening_file() -> Result<File, Error> {
    match File::open("foo_file.txt"){
        Ok(file) => Ok(file),
        Err(error) => Err(error)
    }
}

fn open_file(file_name: String) -> File{
    let open_result = File::open(file_name.clone());

    let file = match open_result{
        Ok(f) => f,
        Err(error) => {
            match error.kind() {
                ErrorKind::NotFound => {
                    match File::create(file_name.clone())
                    {
                        Ok(f)=> f,
                        Err(error) =>{
                            panic!("Problem creating the file: {:?}", error)
                        }
                    }
                }
                other_error => {
                    panic!("Problem opening the file: {:?}", error)
                }
            }
        }
    };

    return file;
}

fn crash_program(){
    // panic!("Goodbye, cruel world!");

    let v = vec![1,2,3];

    let q = v[99];

    println!("{}", q)
}
