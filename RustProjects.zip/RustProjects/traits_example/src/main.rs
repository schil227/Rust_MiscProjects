trait Draw{
    fn draw(&self);
}

struct Screen{
    pub components: Vec<Box<dyn Draw>>
}

impl Screen{
    fn run(&self) { 
        for compoennt in self.components.iter(){
            compoennt.draw()
        }
    }
}

struct Button {
    width: u32,
    height: u32,
    label: String
}

impl Draw for Button{
    fn draw(&self) { 
        println!("Drawin a button with width: {}, height: {}, and label:{} wherever the hell I want.", self.width, self.height, self.label);
     }
}

struct SelectBox {
    width: u32,
    height: u32,
    options: Vec<String>
}

impl Draw for SelectBox{
    fn draw(&self) { 
        println!("Drawin a SelectBox with width: {}, height: {}, and options:{:?} wherever the hell I want.", self.width, self.height, self.options);
     }
}

fn main() {
    let button = Button{
        width: 1,
        height: 2,
        label: "Spiders!".to_string()
    };

    let selectBox = SelectBox{
        width: 4,
        height: 4,
        options: vec!["Bing".to_string(), "Bang".to_string()]
    };

    let screen = Screen{
        components: vec![Box::new(selectBox), Box::new(button)]
    };

    screen.run();
}
