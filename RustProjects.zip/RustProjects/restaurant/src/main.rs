mod back_of_house; // brings into local scope
mod front_of_house;

use crate::back_of_house::Breakfast;

fn main() {
    println!("Hello, world!");

    crate::front_of_house::hosting::add_to_waitlist();

    let mut breakfast_order = Breakfast::order_summer_breakfast("wheat");

    // seasonal_fruit is private, and therefore cannot be assigned
    // breakfast.seasonal_fruit = String::from("strawberries");

    breakfast_order.toast = String::from("rye");

    breakfast_order.get_breakfast();
}

   