use crate::front_of_house;

pub struct Breakfast{
    pub toast: String,
    seasonal_fruit: String
}

impl Breakfast{
    pub fn order_summer_breakfast(bread_type: &str) -> Breakfast{
        Breakfast{
            toast: String::from(bread_type),
            seasonal_fruit: String::from("peaches")
        }
    }

    pub fn get_breakfast(&self){
        println!{"Here is your {} toast and our seasonal fruit, {}.", self.toast, self.seasonal_fruit}
    }
}

fn cook_order(){}

fn fix_incorrect_order(){
    cook_order();
    front_of_house::serving::serve_order();
}