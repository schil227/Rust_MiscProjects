pub mod hosting{
    pub fn add_to_waitlist(){}

    fn seat_at_table(){}
}

pub mod serving{
    fn take_order(){}

    pub fn serve_order(){}

    fn receive_payment(){}
}