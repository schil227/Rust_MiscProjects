#[derive(PartialEq, Debug)]
struct Rectangle{
    width: u32,
    height: u32
}

impl Rectangle{
    fn can_hold(&self, other: &Rectangle) -> bool{
        self.width > other.width && self.height > other.height
    }
}

fn main() {
    println!("Hello, world!");
}

fn add_two(a: i32) -> i32{
    if(a == 3){
        panic!("I dont add 2 to 3!");
    }

    a + 2
}
#[cfg(test)]
mod tests2 {
use super::*;

    #[test]
    fn add_two__ASFD_JKL(){
        assert_eq!(3, add_two(1))
    }

}

#[cfg(test)]
mod tests1 {
    use super::*;

    #[test]
    fn new__when_newing_up_rectangle__width_and_height_are_set(){
        let rect = Rectangle{
            height: 10,
            width: 5
        };

        assert_eq!(rect.height, 10);
        assert!(rect.width == 5, "Rect was not equal to 5: {}",  rect.width );
    }

    #[test]
    fn can_hold__when_rectangle_bigger_than_other__returns_true(){
        let larger = Rectangle {
            height: 10,
            width: 5
        };

        let smaller = Rectangle{
            height: 3,
            width: 4
        };

        assert!(larger.can_hold(&smaller));
    }

    #[test]
    fn can_hold__when_rectangle_smaller_than_other__returns_false(){
        let larger = Rectangle {
            height: 10,
            width: 5
        };

        let smaller = Rectangle{
            height: 3,
            width: 4
        };

        assert!(!smaller.can_hold(&larger));
    }

    #[test]
    fn add_two__when_given_a_number__returns_it_plus_two(){
        assert_ne!(5, add_two(2));
    }

    #[test]
    fn add_two__when_given_input_is_2__returns_4(){
        assert_eq!(4, add_two(2));
    }

    #[test]
    #[should_panic(expected = "I dont add 2 to 3!")]
    fn add_two__when_number_is_3__panics(){
        add_two(3);
    }
}