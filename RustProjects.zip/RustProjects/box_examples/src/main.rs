mod customer_data;

use core::ops::DerefMut;
use crate::List::{Cons, Nil};
use std::ops::Deref;
use std::rc::Rc;

use customer_data::CustomerData;

// use crate::customer_data::CustomerData;

// use crate::customer_data::CustomerData;

pub enum List{
    Cons(i32, Rc<List>),
    Nil
}

// tuple struct, apparently
struct MyBox<T>(T);

impl<T> MyBox<T>{
    fn new(x:T) -> MyBox<T>{
        MyBox(x)
    }
}

impl<T> Deref for MyBox<T>{
    type Target = T;
    
    fn deref(&self) -> &<Self as std::ops::Deref>::Target 
    {
         &self.0
    }
}

impl<T> DerefMut for MyBox<T>{
    fn deref_mut(&mut self) -> &mut <Self as std::ops::Deref>::Target { 
        &mut self.0
    }
}

fn run_list(list: &List){
    match list{
        Cons(num, next_list) =>
        {
            println!("Value: {}", num);
            run_list(next_list)
        },
        Nil => {println!("End of list!");}
    }
}

fn main() {
    let list_a = Rc::new(Cons(1, Rc::new(Cons(2, Rc::new(Cons(3, Rc::new(Nil)))))));
    run_list(&list_a);

    let list_b = Cons(88, Rc::clone(&list_a));

    run_list(&list_b);

    let list_c = Cons(99, Rc::clone(&list_a));

    run_list(&list_c);
    // let x = 5;
    // let mut y = MyBox(x);

    // assert_eq!(5, x);
    // assert_eq!(5, *y);

    // let name = MyBox::new("Foo".to_string());
    
    // hello(&name);
    // hello(&(*name));

    // add_value(&mut y, &7);
    // add_value(&mut y, &10);

    // println!("y: {}", y.0);

    // let foo = CustomerData{
    //     data: "foo".to_string()
    // };

    // let bar = CustomerData{
    //     data: "bar".to_string()
    // };

    // let baz = CustomerData{
    //     data: "baz".to_string()
    // };

    // println!("Made Foo, Bar, and Baz: {}, {}, {}", foo.data, bar.data, baz.data);

    // //envoking an early drop of bar
    // std::mem::drop(bar);

    // println!("bar has been dropped.");
}

fn hello(name: &str){
    println!("Hello, {}!", name);
}

fn add_value<'a>(base: &'a mut i32, value: &'a i32){
    // name.push_str(new_name);
    *base += *value;
}