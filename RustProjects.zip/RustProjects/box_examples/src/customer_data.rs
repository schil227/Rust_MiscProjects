pub struct CustomerData{
    pub data: String
}

impl Drop for CustomerData{
    
    fn drop(&mut self) { 
        println!("Goodbye, {}!", self.data);
    }
}