use std::iter::Sum;

pub struct Averager{
    data: Vec<i32>,
    average: f64
}

impl Averager{
    pub fn add(&mut self, item: i32){
        self.data.push(item);
        self.update_average();
    }

    pub fn remove(&mut self) -> Option<i32>{
        let result = self.data.pop();
        match result {
            Some(value) => {
                self.update_average();
                Some(value)
            } 
            None => None
        }
    }

    pub fn get_average(&self) -> f64{
        self.average
    }

    fn update_average(&mut self){
        let total: i32 = self.data.iter().sum();
        self.average = total as f64 / self.data.len() as f64;
    }
}

fn main() {
    let mut averager = Averager{
        data: vec![],
        average: 0.0
    };

    averager.add(4);
    averager.add(3);

    println!("Avg 1: {}", averager.get_average());

    averager.add(2);
    averager.add(5);

    println!("Avg 2: {}", averager.get_average());

    averager.remove();

    println!("Avg 3: {}", averager.get_average());

    averager.remove();

    println!("Avg 4: {}", averager.get_average());
}
