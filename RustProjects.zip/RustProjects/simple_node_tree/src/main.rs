use std::cell::RefCell;
use std::rc::Rc;
// use crate::Node;

#[derive(Debug)]
struct Node{
    value: i32,
    children: RefCell<Vec<Rc<Node>>>
}

impl Node{
    pub fn new(value: i32) -> Node {
        Node{
            value,
            children: RefCell::new(vec![])
        }
    }

    pub fn add_new_child(&self, child_value: i32){
        self.children.borrow_mut().push(
            Rc::new(Node::new(child_value))
        )
    }

    pub fn get_child(&self, id: i32) -> Option<Rc<Node>>{
        let kiddos = self.children.borrow();
        let found_node = kiddos.iter().find(|node| node.value == id);

        match found_node{
            Some(item) => Some(Rc::clone(item)),
            None => None
        }
    }

    pub fn sum_node(&self) -> i32{
        let sum = self.value;

        let kiddos = self.children.borrow();
        let result : i32 = kiddos.iter().map(|item| item.sum_node()).sum();

        sum + result
    }
}

fn main() {
    let root = Node::new(1);

    root.add_new_child(2);
    root.add_new_child(3);

    println!("node: {:#?}", root);

    let kiddo = root.get_child(3).unwrap();

    println!("Kid w/ id 3: {:#?}", kiddo);

    kiddo.add_new_child(4);
    kiddo.add_new_child(5);
    kiddo.add_new_child(6);

    println!("Added a new child to kid 3: {:#?}", kiddo);

    println!("Updated root node: {:#?}", root);

    println!("Root sum: {}", root.sum_node());
    println!("Kiddo sum: {}", kiddo.sum_node());
}

#[cfg(test)]
mod tests{
    use super::*;

    #[test]
    fn NodeNew_WhenGivenData_ReturnsNewNode(){
        // Arrange
        let val = 2;

        // Act
        let new_node = Node::new(val);

        // Assert
        assert_eq!(val, (&new_node).value);
        
        let children = &new_node.children.borrow();

        assert_eq!(0, children.len())
    }

    #[test]
    fn AddNewChild_WhenProvidedValue_CreatesANewChildNode(){
        // Arrange
        let root = Node::new(2);

        // Act
        root.add_new_child(3);

        // Assert
        let children = &root.children.borrow();

        assert_eq!(1, children.len());
        assert_eq!(3, children.first().unwrap().value);
    }

    #[test]
    fn AddNewChild_WhenCalledMultipleTimes_CreatesNewChildNodes(){
        // Arrange
        let root = Node::new(2);

        // Act
        root.add_new_child(3);
        root.add_new_child(4);

        // Assert
        let children = &root.children.borrow();

        assert_eq!(2, children.len());
        assert_eq!(3, children.first().unwrap().value);
        assert_eq!(4, children.last().unwrap().value);
    }
}