fn main() {
    println!("result: {}", apply_something_twice(add_twice, 1));

    println!("Closure: {:?}", get_strings_from_numbers_using_closure(vec![1,2,3]));
    println!("fn: {:?}", get_strings_from_numbers_using_inline_function(vec![1,2,3]));

    println!("Plus_one with closure: {}" ,apply_some_closure(plus_one(), 1));
}

fn add_twice(x:i32) -> i32{
    x + x
}

fn apply_something_twice(funct: fn(i32) -> i32, x: i32) -> i32{
    funct(x) + funct(x)
}

fn apply_some_closure(clos: Box<Fn(i32) -> i32>, x: i32) -> i32{
    clos(x) + clos(x)
}

fn get_strings_from_numbers_using_closure(vec: Vec<i32>) -> Vec<String>{
    vec.iter().map(|i| i.to_string()).collect()
}

fn get_strings_from_numbers_using_inline_function(vec: Vec<i32>) -> Vec<String>{
    vec.iter().map(ToString::to_string).collect()
}

fn plus_one() -> Box<dyn Fn(i32) -> i32> {
    Box::new(|x| x + 1)
}