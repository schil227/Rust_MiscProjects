mod strs;
mod hash_map;
mod quicksort;
mod list_data_service;
mod pig_latin_service;

enum SpreadSheetCell{
    Integer(i32),
    Float(f32),
    Text(String)
}

fn GetSpreadSheetData() -> Vec<SpreadSheetCell>{
    vec![
        SpreadSheetCell::Integer(14),
        SpreadSheetCell::Float(3.14),
        SpreadSheetCell::Text(String::from("Not a Triangle"))
    ]
}

fn main() {
    // strs::string_stuff();
    //hash_map::hash_map_stuff();
    
    // let mut data = vec![3,7,8,5,2,1,9,5,4];
    // let list_data = list_data_service::get_list_data(&mut data);
    // list_data.to_string();

    let input = String::from("Hand me an ordinary goldfish cracker please. All of them will suffice.");

    println!("{}", pig_latin_service::convert_to_pig_latin(&input));
}

fn vect_demo(){
    let mut myVect: Vec<i32> = Vec::new();
    let yourVect = vec![1,2,3];

    myVect.push(yourVect[0]);
    myVect.push(yourVect[1]);
    myVect.push(yourVect[2]);
    myVect.push(4);
    myVect.push(5);

    myVect.reverse();

    for i in &myVect {
        println!("{}!", i);
    }

    println!("BLASTOFF!");

    match myVect.get(2){
        Some(num)=> println!("The element at 2 is {}.", num),
        None => println!("No element found at 2.")
    };

    for i in &mut myVect{
        *i = (*i * *i) as i32; // i multiplied by itself - wild.
    }

    printVec(&myVect);

    let myVect = GetSpreadSheetData();

    print_cell_data(&myVect);
}

fn printVec(vect: &Vec<i32>){
    for i in vect{
        print!("{} ", i)
    }

    println!();
}

fn print_cell_data(data: &Vec<SpreadSheetCell>){
    for i in data{
        match i{
            SpreadSheetCell::Integer(num) => println!("number: {}", num),
            SpreadSheetCell::Float(f) => println!("Float: {}", f),
            SpreadSheetCell::Text(text) => println!("{}", text)
        };
    }
}