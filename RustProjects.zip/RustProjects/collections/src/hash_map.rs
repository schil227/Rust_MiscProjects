use std::collections::HashMap;

pub fn hash_map_stuff(){
    let mut map = HashMap::new();

    map.insert("Blue".to_string(), 10);
    map.insert("Yellow".to_string(), 50);

    let teams = vec!["Blue".to_string(), "Yellow".to_string()];
    let scores = vec![10, 50];

    // let teams_iter = (&teams).into_iter();
    // let score_iter = scores.into_iter();

    // let team_score_zip = teams_iter.zip(score_iter);

    // let team_score_map: HashMap<_,_> = team_score_zip.collect();

    //or
    let mut team_score_alt: HashMap<_,_> = teams.into_iter().zip(scores.into_iter()).collect();

    assert_eq!(map["Blue"], 10);
    assert_eq!(map["Yellow"], 50);

    assert_eq!(team_score_alt["Blue"], 10);
    assert_eq!(team_score_alt["Yellow"], 50);

    map.insert("Blue".to_string(), 20);

    match map.get("Blue"){
        Some(num) => println!{"Blue's score is {}", num},
        None => println!("No value returned.")
    }

    // Only insert kv pair if the key does not exist
    team_score_alt.entry("Yellow".to_string()).or_insert(100);
    team_score_alt.entry("Red".to_string()).or_insert(70);

    for (key, value) in &team_score_alt{
        println!("{} : {}", key, value);
    }

    let phrase = "Sally Sells Sea Shells By the Sea Shore She Sally Shells Sea Shells Some";

    let mut phrase_map: HashMap<&str, i32> = HashMap::new();

    for word in phrase.split_whitespace(){
        let count = phrase_map.entry(word).or_insert(0);
        *count += 1;
    }

    println!("{:?}", phrase_map);
}