use crate::quicksort;
use std::collections::HashMap;

pub struct ListData{
    pub mean: f32, // average value
    pub median: i32, // middle number of sorted list
    pub mode: i32, // most freqently occuring number
}

impl ListData{
    pub fn New() -> ListData{
        ListData{
            mean: 0.0,
            median: 0,
            mode: 0
        }
    }

    pub fn to_string(&self){
        println!("Mean: {}, Median:{}, Mode:{}", self.mean, self.median, self.mode)
    }
}

pub fn get_list_data(vect: &mut Vec<i32>) -> ListData{
    let mut data = ListData::New();

    quicksort::sort(vect);

    // pretty neat; fold() takes the result of applying a function to a list of data; in this case,
    // acc is the accumulator for the function, 0 is what its initialized as, and x is the element
    // in the enum. the expression { acc + x } adds x to the accumulator, and returns the final 
    // value of the accumulator.
    data.mean = vect.iter().fold(0, |acc, x| acc + x) as f32 / (vect.len() as f32);

    match vect.get(vect.len()/2){
        Some(num) => data.median = *num,
        None => {},
    }

    let mut num_occurances: HashMap<i32, i32> = HashMap::new();

    for index in vect{
        let count = num_occurances.entry(*index).or_insert(0);
        *count += 1;
    }

    match num_occurances.iter().max_by(|a, b| a.1.cmp(&b.1)){
        Some((k,v)) => data.mode = *k,
        None => {}
    }

    return data;
}