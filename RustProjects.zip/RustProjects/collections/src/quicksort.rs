pub fn sort(mut vect: &mut Vec<i32>){
    println!("SORTING: {:?}", vect);

    let len = vect.len() - 1;

    sort_recursive(&mut vect, 0, len);

    println!("SORTED: {:?}", vect);
}

fn sort_recursive(vect: &mut Vec<i32>, start: usize, end: usize){
    if start >= end{
        return;
    }
    
    let mut pivot = start;
    let mut index = end;

    loop{
        if pivot >= index {
            break;
        }

        if vect[pivot] > vect[index] {
            vect.swap(pivot, pivot + 1);
            
            pivot += 1;

            if pivot == index{
                break;
            }else{
                vect.swap(pivot - 1, index);
            }
        }
        else{
            index -= 1;
        }
    }

    //since pivot is of type usize, it cannot be less than 0 or rust will panic.
    if pivot != 0 && pivot - 1 > start {
        sort_recursive(vect, start, pivot - 1);
    }
    
    if pivot +1 < end {
        sort_recursive(vect, pivot + 1, end);
    }
}

// swapping:
// since two elements in a list cannot be mutable at the same time, the built-in swap() function is used. Under the covers,
// it is acquiring the pointer to the structs stored at the given indicies, and doing some unsafe pointer swapping.