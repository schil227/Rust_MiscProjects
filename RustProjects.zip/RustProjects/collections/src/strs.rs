pub fn string_stuff(){
    let myStr = String::from("Hello!");
    let yourStr = "Goodbye!".to_string();

    let mut newStr = myStr + &" ".to_string() + &yourStr;

    newStr.push_str(" Hello again");

    newStr.push('!');

    println!("{}", newStr);

    let s1 = "tic".to_string();
    let s2 = "tac".to_string();
    let s3 = "toe".to_string();

    let ttt = format!("{}-{}-{}", s1, s2, s3);
    println!("{}, and we still have ownership of {}, {} and {}!",ttt, s1, s2, s3);

    // we lose ownership of s1, cause the first argument when using '+' on strings
    // is sacrificed to the gods, whereas all others are coersed into string references ('&str'):

    // let s4 = s1 + &s2;
    // println!("{}, and we still have ownership of {}, {} {}!",ttt, s1, s2, s3);
}