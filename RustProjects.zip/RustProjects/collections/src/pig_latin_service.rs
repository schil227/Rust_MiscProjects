use std::str;

const vowels: [char; 5] = ['a','e','i','o','u'];

pub fn convert_to_pig_latin(input: &str)-> String{
    
    let words = input.split_whitespace();

    let mut phrase = String::new();

    // Boy, what a pile of shit.
    for word in words{
        match (word.chars().nth(0)){
            Some(first_letter) => {
                if vowels.contains(&first_letter){
                    phrase.push_str(word);// (format!("{}-{} ", word, "hay"));
                    phrase.push_str("-hay "); 
                }
                else{
                    phrase.push_str(&word[1..]);
                    phrase.push(first_letter);
                    phrase.push_str("ay ");
                }
            },
            None => {}
        }
    }

    return phrase;
}