
fn main(){
    for i in 0..256u16{
        let duty: &u16 = &(i * i / 256);
        println!("{}, {}, {}", i, duty, (*duty) as u8);
    }
}