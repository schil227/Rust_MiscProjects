use rand::Rng;

struct Person{
    age: u8,
    name: String
}

enum CauseOfDeath{
    Drowned,
    Stabbed,
    OldAge
}

enum Status{
    Alive(Person),
    Dead(CauseOfDeath, Person)
}

enum Parity{
    Even,
    Odd
}

impl Person{
    fn create_person(age: u8, name: String) -> Person{
        return Person{
            age,
            name
        }
    }

    fn age_person(&mut self) -> Option<&mut Person>{
        let chance_of_survival_upper_limit = std::cmp::max(100 - self.age, 2);

        if rand::thread_rng().gen_range(0,chance_of_survival_upper_limit) != 0{
            self.age += 1;
            return Some(self);
        }

        return None;
    }

    fn say_hi(&self){
        println!("\"Hello! I'm {} and I'm {} years old.\"", self.name, self.age);
    }
}

impl Parity{
    fn get_random() -> Parity{
        if rand::thread_rng().gen_range(0,2) == 0{
            return Parity::Even;
        }

        return Parity::Odd
    }
}

fn main() {
    let name = String::from("Bill");

    live_life(&mut Person::create_person(0, name));

    let five = plus_one(&Some(5));
    let six = plus_one(&five);
    let none = plus_one(&None);


    print_option(five);
    print_option(six);
    print_option(none);
}

fn live_life(person: &mut Person){

    loop
    {
     match person.age_person(){
         Some(_aged_person) => println!("{} is now {} years old.", _aged_person.age, _aged_person.name),
         None => break
     }
    }

    println!("{} lived to be {} years old!", person.name, person.age);
}

fn print_option(option: Option<i32>){
    match option{
        Some(num) => println!("has value! {}", num),
        None => println!("no value.")
    }
}

fn plus_one(foo: &Option<i32>) -> Option<i32>{
    match foo{
        Some(num) => Some(num+1),
        None => None
    }
}