use std::sync::Mutex;
use std::sync::Arc;
use std::thread;

fn main() {
    let counter = Arc::new(Mutex::new(0));

    let mut thread_handles = vec![];

    for _i in 0..10
    {
        let counter_clone = Arc::clone(&counter);

        thread_handles.push(thread::spawn(move || {
            let mut count = counter_clone.lock().unwrap();
            *count += 1;
        }));
    }

    for handle in thread_handles{
        handle.join().unwrap();
    }

    print!("count: {}", (*counter.lock().unwrap()));
}
